#! /usr/bin/env python
# -*- coding: utf-8 -*-


from __future__ import absolute_import
from __future__ import print_function


import cv2
from matplotlib import pyplot as plt
import pylab as pl


import transform


img = cv2.imread('romaa.jpg', cv2.IMREAD_GRAYSCALE)

dst = transform.translate(img, x=100, y=100)

pl.gray(), pl.axis('equal'), pl.axis('off')
plt.subplot(121), plt.imshow(img), plt.title('Input')
plt.subplot(122), plt.imshow(dst), plt.title('Output')
plt.show()
