#! /usr/bin/env python
# -*- coding: utf-8 -*-


import cv2


modes = {'x': 0, 'y': 1, 'b': -1}


def flip(img, mode):
    if(mode not in modes.keys()):
        return img

    flipped = cv2.flip(img, modes[mode])

    return flipped
